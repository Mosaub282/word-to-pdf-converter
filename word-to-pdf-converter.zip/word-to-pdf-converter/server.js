const express = require('express');
const multer = require('multer');
const fs = require('fs');
const libre = require('libreoffice-convert');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

const upload = multer({ dest: 'uploads/' });

app.get('/', (req, res) => {
  res.send(`
    <h2>🚀 أداة تحويل Word إلى PDF (مع دعم العربية)</h2>
    <form method="POST" action="/convert" enctype="multipart/form-data">
      <input type="file" name="file" accept=".docx" required />
      <button type="submit">ابدأ التحويل</button>
    </form>
  `);
});

app.post('/convert', upload.single('file'), (req, res) => {
  const file = req.file;
  const ext = '.pdf';
  const inputPath = file.path;

  const docxBuf = fs.readFileSync(inputPath);

  libre.convert(docxBuf, ext, undefined, (err, done) => {
    if (err) {
      console.error('فشل التحويل:', err);
      return res.status(500).send('خطأ في التحويل.');
    }

    const outputName = `${file.originalname.replace(/\.docx$/, '')}.pdf`;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${outputName}"`);
    res.send(done);

    fs.unlinkSync(inputPath);
  });
});

app.listen(PORT, () => console.log(`🚀 السيرفر يعمل على http://localhost:${PORT}`));